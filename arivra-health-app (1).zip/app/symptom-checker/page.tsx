"use client"

import { useState } from "react"
import { ArrowLeft, Send, AlertTriangle, BookOpen, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

interface Message {
  type: "user" | "bot"
  content: string
  suggestions?: Array<{
    condition: string
    remedy: string
    warning: string
  }>
}

export default function SymptomChecker() {
  const [messages, setMessages] = useState<Message[]>([
    {
      type: "bot",
      content:
        "Hello! I'm ArivBot, your basic health assistant. I can help you understand common symptoms and provide general guidance. Please describe what you're experiencing.",
    },
  ])
  const [inputValue, setInputValue] = useState("")

  const getResponse = (symptom: string): Message => {
    const lower = symptom.toLowerCase()

    // Headache responses
    if (lower.includes("headache") || lower.includes("head pain") || lower.includes("migraine")) {
      return {
        type: "bot",
        content: "Based on your headache symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Tension Headache",
            remedy: "Rest in a quiet dark room, apply cold compress to forehead, stay hydrated",
            warning:
              "See a doctor if headache is severe, sudden, or accompanied by fever, stiff neck, confusion, or vision changes",
          },
        ],
      }
    }

    // Fever/chills
    if (lower.includes("fever") || lower.includes("chills") || lower.includes("temperature")) {
      return {
        type: "bot",
        content: "Based on your fever symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Fever (Possible Infection)",
            remedy: "Rest, drink plenty of fluids, use acetaminophen or ibuprofen for comfort",
            warning:
              "See a doctor if fever is above 103°F (39.4°C), lasts more than 3 days, or accompanied by severe symptoms",
          },
        ],
      }
    }

    // Cough/cold
    if (
      lower.includes("cough") ||
      lower.includes("cold") ||
      lower.includes("runny nose") ||
      lower.includes("sore throat")
    ) {
      return {
        type: "bot",
        content: "Based on your cold symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Common Cold",
            remedy: "Rest, fluids, honey for sore throat, saline nasal spray",
            warning:
              "See a doctor if fever exceeds 101.3°F, symptoms worsen after 10 days, or you have difficulty breathing",
          },
        ],
      }
    }

    // Stomach issues
    if (
      lower.includes("stomach") ||
      lower.includes("nausea") ||
      lower.includes("vomit") ||
      lower.includes("diarrhea")
    ) {
      return {
        type: "bot",
        content: "Based on your digestive symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Gastroenteritis (Stomach Bug)",
            remedy: "Stay hydrated with clear fluids, eat bland foods (BRAT diet), rest",
            warning:
              "See a doctor if you have bloody stools, severe dehydration, high fever, or symptoms lasting more than 2 days",
          },
        ],
      }
    }

    // Rash/skin issues
    if (lower.includes("rash") || lower.includes("hives") || lower.includes("itch") || lower.includes("skin")) {
      return {
        type: "bot",
        content: "Based on your skin symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Allergic Reaction / Contact Dermatitis",
            remedy: "Avoid trigger if known, apply cool compress, use over-the-counter hydrocortisone cream",
            warning:
              "Seek immediate care if you have difficulty breathing, swelling of face/throat, or rapidly spreading rash",
          },
        ],
      }
    }

    // Pain (general)
    if (lower.includes("pain") || lower.includes("ache") || lower.includes("hurt")) {
      return {
        type: "bot",
        content: "Based on your pain symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "General Pain / Inflammation",
            remedy: "Rest the affected area, apply ice for first 48 hours, use over-the-counter pain relievers",
            warning:
              "See a doctor if pain is severe, worsening, or accompanied by swelling, numbness, or inability to move the area",
          },
        ],
      }
    }

    // Fatigue/tired
    if (lower.includes("tired") || lower.includes("fatigue") || lower.includes("weak") || lower.includes("exhausted")) {
      return {
        type: "bot",
        content: "Based on your fatigue symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Fatigue",
            remedy: "Ensure 7-9 hours of sleep, stay hydrated, eat balanced meals, manage stress",
            warning:
              "See a doctor if fatigue is persistent, unexplained, or accompanied by other symptoms like fever or weight loss",
          },
        ],
      }
    }

    // Dizziness
    if (lower.includes("dizzy") || lower.includes("vertigo") || lower.includes("lightheaded")) {
      return {
        type: "bot",
        content: "Based on your dizziness symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Dizziness / Vertigo",
            remedy: "Sit or lie down immediately, stay hydrated, avoid sudden movements",
            warning:
              "Seek immediate care if accompanied by chest pain, severe headache, loss of consciousness, or difficulty speaking",
          },
        ],
      }
    }

    // Breathing issues
    if (lower.includes("breath") || lower.includes("breathing") || lower.includes("wheez")) {
      return {
        type: "bot",
        content: "Based on your breathing symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Shortness of Breath",
            remedy: "Sit upright, breathe slowly and deeply, stay calm",
            warning: "CALL 911 if you have severe difficulty breathing, chest pain, or blue lips/face",
          },
        ],
      }
    }

    // Chest pain
    if (lower.includes("chest pain") || lower.includes("chest pressure") || lower.includes("chest tight")) {
      return {
        type: "bot",
        content: "⚠️ CHEST PAIN CAN BE SERIOUS:",
        suggestions: [
          {
            condition: "Possible Cardiac or Respiratory Issue",
            remedy: "CALL 911 IMMEDIATELY if severe, with shortness of breath, or radiating to arm/jaw",
            warning:
              "DO NOT WAIT - Call 911 for severe chest pain, especially with sweating, nausea, or shortness of breath",
          },
        ],
      }
    }

    // Back pain
    if (lower.includes("back pain") || lower.includes("lower back") || lower.includes("spine")) {
      return {
        type: "bot",
        content: "Based on your back pain symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Muscle Strain / Mechanical Back Pain",
            remedy: "Rest, ice for first 48 hours then heat, gentle stretching, over-the-counter pain relievers",
            warning: "See a doctor if pain radiates down legs, causes numbness/weakness, or follows trauma",
          },
        ],
      }
    }

    // Joint pain
    if (
      lower.includes("joint") ||
      lower.includes("arthritis") ||
      lower.includes("knee pain") ||
      lower.includes("elbow pain")
    ) {
      return {
        type: "bot",
        content: "Based on your joint symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Joint Pain / Inflammation",
            remedy: "Rest joint, apply ice, elevate if swollen, use over-the-counter anti-inflammatory",
            warning: "See a doctor if joint is hot/red/very swollen, you can't bear weight, or pain is severe",
          },
        ],
      }
    }

    // Allergies
    if (
      lower.includes("allergy") ||
      lower.includes("sneez") ||
      lower.includes("watery eyes") ||
      lower.includes("congestion")
    ) {
      return {
        type: "bot",
        content: "Based on your allergy symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Allergic Rhinitis / Seasonal Allergies",
            remedy: "Avoid triggers, use antihistamines, nasal saline rinse, keep windows closed",
            warning: "Seek immediate care if you have difficulty breathing, throat swelling, or facial swelling",
          },
        ],
      }
    }

    // Insomnia/sleep
    if (lower.includes("sleep") || lower.includes("insomnia") || lower.includes("can't sleep")) {
      return {
        type: "bot",
        content: "Based on your sleep symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Insomnia / Sleep Difficulty",
            remedy:
              "Maintain sleep schedule, avoid screens before bed, create dark/cool room, avoid caffeine after 2pm",
            warning: "See a doctor if insomnia persists for weeks, affects daily function, or you suspect sleep apnea",
          },
        ],
      }
    }

    // Anxiety
    if (
      lower.includes("anxiety") ||
      lower.includes("anxious") ||
      lower.includes("panic") ||
      lower.includes("worried")
    ) {
      return {
        type: "bot",
        content: "Based on your anxiety symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Anxiety",
            remedy: "Deep breathing exercises, regular exercise, limit caffeine, practice mindfulness, talk to someone",
            warning: "See a mental health professional if anxiety interferes with daily life or you have panic attacks",
          },
        ],
      }
    }

    // Ear pain/infection
    if (lower.includes("ear") || lower.includes("earache") || lower.includes("ear pain")) {
      return {
        type: "bot",
        content: "Based on your ear symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Ear Infection / Ear Pain",
            remedy: "Warm compress on ear, over-the-counter pain reliever, stay hydrated",
            warning:
              "See a doctor if severe pain, fever above 102°F, fluid draining from ear, or symptoms last more than 2 days",
          },
        ],
      }
    }

    // Eye issues
    if (lower.includes("eye") || lower.includes("vision") || lower.includes("blurry") || lower.includes("red eyes")) {
      return {
        type: "bot",
        content: "Based on your eye symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Eye Irritation / Conjunctivitis",
            remedy: "Artificial tears, warm compress, avoid rubbing eyes, wash hands frequently",
            warning:
              "See a doctor immediately if sudden vision loss, severe pain, seeing flashes/floaters, or eye injury",
          },
        ],
      }
    }

    // UTI symptoms
    if (
      lower.includes("urinary") ||
      lower.includes("uti") ||
      (lower.includes("burning") && lower.includes("urin")) ||
      lower.includes("frequent urination")
    ) {
      return {
        type: "bot",
        content: "Based on your urinary symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Possible Urinary Tract Infection (UTI)",
            remedy: "Drink plenty of water, urinate frequently, cranberry juice may help",
            warning:
              "See a doctor soon - UTIs need antibiotics. Seek immediate care if fever, back pain, or blood in urine",
          },
        ],
      }
    }

    // Dehydration
    if (lower.includes("dehydrat") || lower.includes("thirsty") || lower.includes("dry mouth")) {
      return {
        type: "bot",
        content: "Based on your dehydration symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Dehydration",
            remedy: "Drink water slowly, electrolyte drinks, rest in cool place, eat water-rich foods",
            warning:
              "Seek immediate care if unable to keep fluids down, very dark urine, confusion, or rapid heartbeat",
          },
        ],
      }
    }

    // Sunburn
    if (lower.includes("sunburn") || lower.includes("sun burn")) {
      return {
        type: "bot",
        content: "Based on your sunburn symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Sunburn",
            remedy: "Cool compresses, aloe vera gel, stay hydrated, take cool baths, use moisturizer",
            warning: "See a doctor if severe blistering, fever, chills, or covering large area of body",
          },
        ],
      }
    }

    // Constipation
    if (lower.includes("constipat") || lower.includes("can't go")) {
      return {
        type: "bot",
        content: "Based on your digestive symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Constipation",
            remedy: "Increase fiber intake, drink more water, exercise regularly, prune juice may help",
            warning: "See a doctor if severe abdominal pain, blood in stool, no bowel movement for more than 3 days",
          },
        ],
      }
    }

    // Heartburn/GERD
    if (lower.includes("heartburn") || lower.includes("acid reflux") || lower.includes("gerd")) {
      return {
        type: "bot",
        content: "Based on your digestive symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Heartburn / Acid Reflux",
            remedy: "Avoid trigger foods, eat smaller meals, don't lie down after eating, elevate head when sleeping",
            warning:
              "See a doctor if heartburn occurs frequently, causes difficulty swallowing, or doesn't respond to over-the-counter medication",
          },
        ],
      }
    }

    // Bleeding
    if (lower.includes("bleeding") || lower.includes("blood")) {
      return {
        type: "bot",
        content: "⚠️ BLEEDING REQUIRES ATTENTION:",
        suggestions: [
          {
            condition: "Bleeding",
            remedy: "Apply direct pressure with clean cloth, elevate if possible, keep pressing for 5+ minutes",
            warning: "CALL 911 for severe bleeding that won't stop, spurting blood, or bleeding from major injury",
          },
        ],
      }
    }

    // Swelling
    if (lower.includes("swell") || lower.includes("swollen") || lower.includes("puffy")) {
      return {
        type: "bot",
        content: "Based on your swelling symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Swelling / Edema",
            remedy: "Elevate affected area, apply ice, reduce salt intake, stay active",
            warning:
              "See a doctor if swelling is sudden, one-sided leg swelling, with shortness of breath, or doesn't improve",
          },
        ],
      }
    }

    // Bruising
    if (lower.includes("bruise") || lower.includes("bruising")) {
      return {
        type: "bot",
        content: "Based on your bruising symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Bruising / Contusion",
            remedy: "Apply ice for first 24 hours, then warm compress, rest area, elevate if possible",
            warning: "See a doctor if bruising appears without injury, excessive bruising, or with unusual bleeding",
          },
        ],
      }
    }

    // Numbness/tingling
    if (lower.includes("numb") || lower.includes("tingle") || lower.includes("pins and needles")) {
      return {
        type: "bot",
        content: "Based on your nerve symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Numbness / Tingling (Paresthesia)",
            remedy: "Change position, stretch gently, shake out limb, apply warm compress",
            warning:
              "SEEK IMMEDIATE CARE if sudden onset with weakness, facial drooping, confusion, or after head injury",
          },
        ],
      }
    }

    // Muscle cramps
    if (lower.includes("cramp") || lower.includes("muscle spasm") || lower.includes("charlie horse")) {
      return {
        type: "bot",
        content: "Based on your muscle symptoms, here are some possibilities:",
        suggestions: [
          {
            condition: "Muscle Cramps",
            remedy: "Stretch and massage muscle, apply heat, stay hydrated, increase potassium and magnesium",
            warning:
              "See a doctor if cramps are severe, frequent, not related to exercise, or cause significant weakness",
          },
        ],
      }
    }

    // Default response
    return {
      type: "bot",
      content:
        "I can help with common symptoms like headaches, fever, cough, stomach issues, rashes, pain, fatigue, dizziness, chest pain, back pain, joint pain, allergies, insomnia, anxiety, ear pain, eye issues, UTI symptoms, dehydration, sunburn, constipation, heartburn, bleeding, swelling, bruising, and numbness. Please describe your specific symptoms, and I'll provide relevant information.",
    }
  }

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const userMessage: Message = { type: "user", content: inputValue }
    setMessages((prev) => [...prev, userMessage])

    // Get response based on symptoms
    setTimeout(() => {
      const botResponse = getResponse(inputValue)
      setMessages((prev) => [...prev, botResponse])
    }, 1000)

    setInputValue("")
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">ArivBot: Your Health Assistant</h1>
          <p className="text-sm text-white/90">Not a diagnosis. Just helpful guidance.</p>
        </div>
      </div>

      {/* Chat Window */}
      <div className="max-w-md mx-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
            {message.type === "user" ? (
              <div className="bg-[#a27a69] text-white p-3 rounded-2xl rounded-br-md max-w-xs">{message.content}</div>
            ) : (
              <div className="space-y-3 max-w-xs">
                <div className="bg-[#efddc7] dark:bg-gray-700 dark:text-gray-100 p-3 rounded-2xl rounded-bl-md">
                  {message.content}
                </div>
                {message.suggestions &&
                  message.suggestions.map((suggestion, idx) => (
                    <Card key={idx} className="border-[#a27a69] border-l-4 dark:bg-gray-800">
                      <CardContent className="p-3">
                        <h4 className="font-heading font-normal text-[#a27a69] mb-2">💡 {suggestion.condition}</h4>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                          <strong>Home remedy:</strong> {suggestion.remedy}
                        </p>
                        <div className="bg-red-50 dark:bg-red-950 p-2 rounded-lg flex items-start">
                          <AlertTriangle className="w-4 h-4 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                          <p className="text-xs text-red-700 dark:text-red-300">{suggestion.warning}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* CTA Buttons */}
      {messages.length > 1 && (
        <div className="max-w-md mx-auto px-4 mb-4">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-[#a27a69] text-[#a27a69] dark:text-[#a27a69] bg-transparent"
              onClick={() => setMessages([messages[0]])}
            >
              Try another symptom
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-[#a27a69] text-[#a27a69] dark:text-[#a27a69] bg-transparent"
            >
              <Save className="w-4 h-4 mr-1" />
              Save this info
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-[#a27a69] text-[#a27a69] dark:text-[#a27a69] bg-transparent"
            >
              <BookOpen className="w-4 h-4 mr-1" />
              When to see a doctor
            </Button>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-[#efddc7] dark:border-gray-700 p-4">
        <div className="max-w-md mx-auto flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Describe your symptoms..."
            className="flex-1 dark:bg-gray-800 dark:text-gray-100"
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Button onClick={handleSendMessage} className="bg-[#a27a69] hover:bg-[#8d6b5a]">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
