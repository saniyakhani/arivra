import type React from "react"
import { League_Spartan, Sanchez } from "next/font/google"
import "./globals.css"
import { Providers } from "./providers"

const leagueSpartan = League_Spartan({
  subsets: ["latin"],
  variable: "--font-league-spartan",
})

const sanchez = Sanchez({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-sanchez",
})

export const metadata = {
  title: "Arivra Health",
  description: "Making medical knowledge accessible to everyone",
    generator: 'v0.app'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${leagueSpartan.variable} ${sanchez.variable} font-sans`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
