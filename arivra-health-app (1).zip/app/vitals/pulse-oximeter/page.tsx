import { ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function PulseOximeterGuide() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/vitals">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Use a Pulse Oximeter</h1>
          <p className="text-sm text-white/90">Measure oxygen levels</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4 space-y-6">
        {/* Tools Needed */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🛠️ Tools Needed</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>• Pulse oximeter device (fingertip style)</li>
              <li>• Clean, dry finger</li>
              <li>• Remove nail polish if wearing any</li>
            </ul>
          </CardContent>
        </Card>

        {/* Where to Place */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📍 Where to Place Device</h3>
            <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
              <p>• Most accurate: Index or middle finger</p>
              <p>• Insert finger all the way into the device</p>
              <p>• Make sure fingernail faces up</p>
              <p>• Can also use toes or earlobes if needed</p>
            </div>
          </CardContent>
        </Card>

        {/* Steps */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📋 Steps</h3>
            <ol className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>1. Sit down and rest for a few minutes</li>
              <li>2. Make sure finger is warm and relaxed</li>
              <li>3. Clip device onto finger (or toe/earlobe)</li>
              <li>4. Keep hand still and below heart level</li>
              <li>5. Wait 5-10 seconds for reading to stabilize</li>
              <li>6. Read both SpO2 (oxygen) and pulse rate</li>
              <li>7. Record your results</li>
            </ol>
          </CardContent>
        </Card>

        {/* What to Expect */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🔍 What to Expect</h3>
            <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
              <p>
                <strong>The device shows two numbers:</strong>
              </p>
              <p>
                • <strong>SpO2 (%)</strong> - Oxygen saturation level
              </p>
              <p>
                • <strong>PR (bpm)</strong> - Pulse rate (heart rate)
              </p>
              <p className="pt-2">
                The reading may take a few seconds to appear and should be steady before you record it.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* What Numbers Mean */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📊 What the Numbers Mean</h3>
            <div className="space-y-3 text-sm">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">Normal oxygen:</span>
                  <span className="font-heading text-green-600 dark:text-green-400">95-100%</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">Mildly low:</span>
                  <span className="font-heading text-yellow-600 dark:text-yellow-400">90-94%</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">Low (seek care):</span>
                  <span className="font-heading text-red-600 dark:text-red-400">{"<90%"}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* When to See Doctor */}
        <Card className="bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-red-800 dark:text-red-200 mb-2">🚨 When to See a Doctor</h3>
            <ul className="text-sm text-red-700 dark:text-red-300 space-y-1">
              <li>• Oxygen level below 90%</li>
              <li>• Shortness of breath or difficulty breathing</li>
              <li>• Chest pain or rapid heartbeat</li>
              <li>• Blue lips or fingernails</li>
              <li>• Confusion or extreme drowsiness</li>
            </ul>
          </CardContent>
        </Card>

        {/* Tips */}
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-blue-800 dark:text-blue-200 mb-2">
              💡 Tips for Accurate Readings
            </h3>
            <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
              <li>• Remove nail polish or artificial nails</li>
              <li>• Warm up cold hands before testing</li>
              <li>• Stay still during measurement</li>
              <li>• Take multiple readings if first seems off</li>
              <li>• Keep device clean and store properly</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
