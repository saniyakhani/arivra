import { ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function BloodPressureGuide() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/vitals">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Use a Blood Pressure Cuff</h1>
          <p className="text-sm text-white/90">Measure your blood pressure</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4 space-y-6">
        {/* Tools Needed */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🛠️ Tools Needed</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>• Digital or manual blood pressure cuff</li>
              <li>• Bare arm (remove tight clothing)</li>
              <li>• Chair with back support</li>
              <li>• Quiet environment</li>
            </ul>
          </CardContent>
        </Card>

        {/* Preparation */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🎯 Before You Start</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>• Don't smoke, exercise, or drink caffeine 30 minutes before</li>
              <li>• Empty your bladder</li>
              <li>• Sit quietly for 5 minutes before measuring</li>
              <li>• Take reading at the same time each day</li>
            </ul>
          </CardContent>
        </Card>

        {/* Steps */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📋 Steps</h3>
            <ol className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>1. Sit with back supported and feet flat on floor</li>
              <li>2. Rest arm on table at heart level</li>
              <li>3. Wrap cuff around bare upper arm, 1 inch above elbow bend</li>
              <li>4. Make sure cuff is snug but not too tight</li>
              <li>5. Press start button on digital cuff (or pump manually)</li>
              <li>6. Stay still and quiet during measurement</li>
              <li>7. Record both numbers (systolic/diastolic)</li>
            </ol>
          </CardContent>
        </Card>

        {/* What Numbers Mean */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📊 What the Numbers Mean</h3>
            <div className="space-y-3 text-sm">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">Normal:</span>
                  <span className="font-heading text-green-600 dark:text-green-400">{"<120/80"}</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">Elevated:</span>
                  <span className="font-heading text-yellow-600 dark:text-yellow-400">120-129/{"<80"}</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">High (Stage 1):</span>
                  <span className="font-heading text-orange-600 dark:text-orange-400">130-139/80-89</span>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-gray-700 dark:text-gray-300">High (Stage 2):</span>
                  <span className="font-heading text-red-600 dark:text-red-400">≥140/90</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* When to See Doctor */}
        <Card className="bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-red-800 dark:text-red-200 mb-2">🚨 When to See a Doctor</h3>
            <ul className="text-sm text-red-700 dark:text-red-300 space-y-1">
              <li>• Blood pressure above 180/120</li>
              <li>• Consistent readings above 130/80</li>
              <li>• Chest pain, shortness of breath, or severe headache</li>
              <li>• Vision changes or difficulty speaking</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
