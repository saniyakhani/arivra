import { ArrowLeft, Hand, Activity, Droplets } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function VitalsGuide() {
  const guides = [
    {
      title: "Check Your Pulse",
      icon: Hand,
      description: "Learn to find and count your pulse",
      href: "/vitals/pulse",
      color: "text-blue-500",
    },
    {
      title: "Use a Blood Pressure Cuff",
      icon: Activity,
      description: "Proper blood pressure measurement",
      href: "/vitals/blood-pressure",
      color: "text-green-500",
    },
    {
      title: "Use a Pulse Oximeter",
      icon: Droplets,
      description: "Monitor oxygen saturation",
      href: "/vitals/pulse-oximeter",
      color: "text-red-500",
    },
  ]

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Vitals Check Guide</h1>
          <p className="text-sm text-white/90">Monitor your health at home</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h3 className="font-heading font-normal text-blue-800 mb-2">📊 Why Check Vitals?</h3>
          <p className="text-sm text-blue-700">
            Regular vital sign monitoring helps you understand your baseline health and detect changes early.
          </p>
        </div>

        <div className="space-y-4">
          {guides.map((guide, index) => (
            <Link key={index} href={guide.href}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-[#efddc7] hover:border-[#a27a69]">
                <CardContent className="p-4 flex items-center">
                  <guide.icon className={`w-12 h-12 ${guide.color} mr-4`} />
                  <div className="flex-1">
                    <h3 className="font-heading font-normal text-gray-800 mb-1">{guide.title}</h3>
                    <p className="text-sm text-gray-600">{guide.description}</p>
                  </div>
                  <div className="text-[#a27a69]">→</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Normal Ranges Reference */}
        <Card className="mt-8 bg-[#efddc7] border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📋 Normal Adult Ranges</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Heart Rate:</span>
                <span className="font-heading">60-100 bpm</span>
              </div>
              <div className="flex justify-between">
                <span>Blood Pressure:</span>
                <span className="font-heading">{"<120/80 mmHg"}</span>
              </div>
              <div className="flex justify-between">
                <span>Oxygen Saturation:</span>
                <span className="font-heading">95-100%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
