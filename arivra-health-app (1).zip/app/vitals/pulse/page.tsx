import { ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function PulseGuide() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/vitals">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Check Your Pulse</h1>
          <p className="text-sm text-white/90">Measure your heart rate</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4 space-y-6">
        {/* Tools Needed */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🛠️ Tools Needed</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>• Your fingers (index and middle finger)</li>
              <li>• A watch or timer with seconds</li>
              <li>• A quiet place to sit</li>
            </ul>
          </CardContent>
        </Card>

        {/* Where to Find Pulse */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📍 Where to Place Fingers</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-heading font-normal text-gray-800 dark:text-gray-200 mb-2">Wrist (Radial Pulse)</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  Place two fingers on the inside of your wrist, below the base of your thumb. Press lightly until you
                  feel the pulse.
                </p>
              </div>
              <div>
                <h4 className="font-heading font-normal text-gray-800 dark:text-gray-200 mb-2">Neck (Carotid Pulse)</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  Place two fingers on either side of your windpipe, just below your jaw. Press gently.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Steps */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📋 Steps</h3>
            <ol className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
              <li>1. Sit down and rest for 5 minutes</li>
              <li>2. Find your pulse using wrist or neck method</li>
              <li>3. Count the beats for 30 seconds</li>
              <li>4. Multiply that number by 2 to get beats per minute (BPM)</li>
              <li>5. Record your result</li>
            </ol>
          </CardContent>
        </Card>

        {/* What Numbers Mean */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📊 What the Numbers Mean</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-700 dark:text-gray-300">Normal resting heart rate:</span>
                <span className="font-heading text-gray-800 dark:text-gray-200">60-100 BPM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700 dark:text-gray-300">Athletes:</span>
                <span className="font-heading text-gray-800 dark:text-gray-200">40-60 BPM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700 dark:text-gray-300">After exercise:</span>
                <span className="font-heading text-gray-800 dark:text-gray-200">100-170 BPM</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* When to See Doctor */}
        <Card className="bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-yellow-800 dark:text-yellow-200 mb-2">
              ⚠️ When to See a Doctor
            </h3>
            <ul className="text-sm text-yellow-700 dark:text-yellow-300 space-y-1">
              <li>• Resting heart rate consistently above 100 or below 60</li>
              <li>• Irregular or skipped beats</li>
              <li>• Chest pain or shortness of breath</li>
              <li>• Dizziness or fainting</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
