"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Moon, Sun, Globe, Info, MessageCircle, FileText, ToggleLeft, ToggleRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useTheme } from "next-themes"

export default function Profile() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [language, setLanguage] = useState("English")

  useEffect(() => {
    setMounted(true)
  }, [])

  const savedItems = [
    { type: "Symptom Check", title: "Common Cold Guidance", date: "2 days ago" },
    { type: "Remedy", title: "Honey & Ginger Tea", date: "1 week ago" },
    { type: "Life-Saving", title: "CPR Instructions", date: "2 weeks ago" },
  ]

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Profile & Settings</h1>
          <p className="text-sm text-white/90">Manage your preferences</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4 space-y-6">
        {/* Settings */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-4">⚙️ Settings</h3>

            <div className="space-y-4">
              {/* Dark Mode Toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {theme === "dark" ? (
                    <Moon className="w-5 h-5 mr-3 text-gray-600 dark:text-gray-400" />
                  ) : (
                    <Sun className="w-5 h-5 mr-3 text-gray-600" />
                  )}
                  <span className="text-gray-800 dark:text-gray-200">Dark Mode</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="p-0"
                >
                  {theme === "dark" ? (
                    <ToggleRight className="w-8 h-8 text-[#a27a69]" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-gray-400" />
                  )}
                </Button>
              </div>

              {/* Language */}
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Globe className="w-5 h-5 mr-3 text-gray-600 dark:text-gray-400" />
                  <span className="text-gray-800 dark:text-gray-200">Language</span>
                </div>
                <span className="text-[#a27a69] font-heading">{language}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Saved Information */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-4">💾 Saved Information</h3>

            {savedItems.length > 0 ? (
              <div className="space-y-3">
                {savedItems.map((item, index) => (
                  <div key={index} className="bg-[#efddc7] dark:bg-gray-700 p-3 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-xs text-[#a27a69] font-heading">{item.type}</span>
                        <h4 className="font-heading font-normal text-gray-800 dark:text-gray-200">{item.title}</h4>
                        <p className="text-xs text-gray-600 dark:text-gray-400">{item.date}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 dark:text-gray-400 text-sm">No saved items yet</p>
            )}
          </CardContent>
        </Card>

        {/* Support & Info */}
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-4">ℹ️ Support & Information</h3>

            <div className="space-y-3">
              <Button variant="ghost" className="w-full justify-start p-3 h-auto dark:hover:bg-gray-700">
                <Info className="w-5 h-5 mr-3 text-gray-600 dark:text-gray-400" />
                <div className="text-left">
                  <div className="font-heading font-normal text-gray-800 dark:text-gray-200">About Arivra Health</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Learn about our mission</div>
                </div>
              </Button>

              <Button variant="ghost" className="w-full justify-start p-3 h-auto dark:hover:bg-gray-700">
                <MessageCircle className="w-5 h-5 mr-3 text-gray-600 dark:text-gray-400" />
                <div className="text-left">
                  <div className="font-heading font-normal text-gray-800 dark:text-gray-200">Contact & Feedback</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Get help or share feedback</div>
                </div>
              </Button>

              <Button variant="ghost" className="w-full justify-start p-3 h-auto dark:hover:bg-gray-700">
                <FileText className="w-5 h-5 mr-3 text-gray-600 dark:text-gray-400" />
                <div className="text-left">
                  <div className="font-heading font-normal text-gray-800 dark:text-gray-200">Terms & Privacy</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Legal information</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Disclaimers */}
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-blue-800 dark:text-blue-200 mb-2">📋 Important Disclaimers</h3>
            <div className="text-sm text-blue-700 dark:text-blue-300 space-y-2">
              <p>• This app provides educational information only</p>
              <p>• Not a substitute for professional medical advice</p>
              <p>• Always consult healthcare providers for medical concerns</p>
              <p>• Call 911 for medical emergencies</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
