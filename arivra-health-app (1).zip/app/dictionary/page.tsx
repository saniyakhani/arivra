"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Search, BookOpen } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

export default function MedicalDictionary() {
  const searchParams = useSearchParams()
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const query = searchParams.get("search")
    if (query) {
      setSearchTerm(query)
    }
  }, [searchParams])

  const terms = [
    {
      term: "Anemia",
      commonName: "Low Blood Count",
      icon: "🩸",
      definition: "Low red blood cells = low oxygen = fatigue.",
      example: "Iron supplements are used to treat anemia.",
    },
    {
      term: "Inflammation",
      commonName: "Swelling",
      icon: "🔥",
      definition: "Body's response to injury or infection causing redness, swelling, heat.",
      example: "Ice can help reduce inflammation in injuries.",
    },
    {
      term: "Hypertension",
      commonName: "High Blood Pressure",
      icon: "💓",
      definition: "High blood pressure that can damage arteries over time.",
      example: "Regular exercise helps manage hypertension.",
    },
    {
      term: "Hypotension",
      commonName: "Low Blood Pressure",
      icon: "💙",
      definition: "Blood pressure that is lower than normal, potentially causing dizziness and fainting.",
      example: "Standing up slowly can help prevent symptoms of hypotension.",
    },
    {
      term: "Diabetes",
      commonName: "High Blood Sugar",
      icon: "🍯",
      definition: "Condition where blood sugar levels are too high.",
      example: "Type 2 diabetes can often be managed with diet and exercise.",
    },
    {
      term: "Antibiotics",
      commonName: "Bacterial Medicine",
      icon: "💊",
      definition: "Medicines that fight bacterial infections (not viral).",
      example: "Antibiotics won't help with a common cold virus.",
    },
    {
      term: "Dermatitis",
      commonName: "Rashes",
      icon: "🔴",
      definition: "Skin inflammation causing red, itchy, or swollen patches on the skin.",
      example: "Contact dermatitis can occur from touching irritating substances.",
    },
    {
      term: "Urticaria",
      commonName: "Hives",
      icon: "🟠",
      definition: "Raised, itchy welts on the skin often caused by allergic reactions.",
      example: "Hives can appear suddenly and may last a few hours or days.",
    },
    {
      term: "Pharyngitis",
      commonName: "Sore Throat",
      icon: "😷",
      definition: "Inflammation of the throat causing pain, scratchiness, or irritation.",
      example: "Viral pharyngitis is the most common cause of sore throats.",
    },
    {
      term: "Rhinorrhea",
      commonName: "Runny Nose",
      icon: "🤧",
      definition: "Excess nasal drainage, often clear and watery from the nose.",
      example: "Rhinorrhea is a common symptom of the common cold and allergies.",
    },
    {
      term: "Dysmenorrhea",
      commonName: "Menstrual Cramps",
      icon: "🔻",
      definition: "Painful menstrual cramps in the lower abdomen before or during periods.",
      example: "Heat therapy and over-the-counter pain relievers can help with dysmenorrhea.",
    },
    {
      term: "Sprain",
      commonName: "Ligament Injury",
      icon: "🦴",
      definition: "Stretching or tearing of ligaments (tissues connecting bones at joints).",
      example: "Ankle sprains are common sports injuries that need rest and ice.",
    },
    {
      term: "Strain",
      commonName: "Muscle Pull",
      icon: "💪",
      definition: "Stretching or tearing of muscles or tendons (tissues connecting muscles to bones).",
      example: "Back strains often occur from lifting heavy objects improperly.",
    },
    {
      term: "Rigors",
      commonName: "Chills",
      icon: "🥶",
      definition: "Feeling of coldness with shivering, often accompanying fever.",
      example: "Chills can be a sign that your body is fighting an infection.",
    },
    {
      term: "Fatigue",
      commonName: "Extreme Tiredness",
      icon: "😴",
      definition: "Persistent feeling of tiredness, weakness, or lack of energy.",
      example: "Chronic fatigue can be caused by various medical conditions or lifestyle factors.",
    },
    {
      term: "Vertigo",
      commonName: "Dizziness",
      icon: "😵",
      definition: "Sensation of spinning or that the room is moving around you.",
      example: "Vertigo can be caused by inner ear problems or other conditions.",
    },
    {
      term: "Paresthesia",
      commonName: "Numbness/Tingling",
      icon: "🫠",
      definition: "Abnormal sensations like numbness, tingling, or 'pins and needles' feeling.",
      example: "Temporary paresthesia can occur from sitting in one position too long.",
    },
    {
      term: "Emesis",
      commonName: "Vomiting",
      icon: "🤮",
      definition: "Forceful expulsion of stomach contents through the mouth.",
      example: "Persistent vomiting requires medical attention to prevent dehydration.",
    },
    {
      term: "Diarrhea",
      commonName: "Loose Stools",
      icon: "💩",
      definition: "Frequent, loose, or watery bowel movements.",
      example: "Staying hydrated is crucial when experiencing diarrhea.",
    },
    {
      term: "Edema",
      commonName: "Swelling",
      icon: "💧",
      definition: "Buildup of fluid in body tissues causing swelling, often in feet, ankles, or legs.",
      example: "Elevating swollen legs can help reduce edema.",
    },
    {
      term: "Tachycardia",
      commonName: "Fast Heart Rate",
      icon: "💗",
      definition: "Heart rate that exceeds normal resting rate (over 100 beats per minute).",
      example: "Anxiety and exercise can both cause temporary tachycardia.",
    },
    {
      term: "Bradycardia",
      commonName: "Slow Heart Rate",
      icon: "💙",
      definition: "Heart rate that is slower than normal (below 60 beats per minute).",
      example: "Athletes often have bradycardia due to their excellent cardiovascular fitness.",
    },
    {
      term: "Dyspnea",
      commonName: "Shortness of Breath",
      icon: "😮‍💨",
      definition: "Difficulty breathing or feeling like you can't get enough air.",
      example: "Severe dyspnea requires immediate medical attention.",
    },
    {
      term: "Cyanosis",
      commonName: "Blue Skin/Lips",
      icon: "🔵",
      definition: "Bluish discoloration of skin and mucous membranes due to lack of oxygen.",
      example: "Cyanosis is a medical emergency requiring immediate attention.",
    },
    {
      term: "Contusion",
      commonName: "Bruise",
      icon: "🟣",
      definition: "Injury causing bleeding under the skin without breaking it.",
      example: "Most contusions heal on their own with rest and ice.",
    },
    {
      term: "Laceration",
      commonName: "Deep Cut",
      icon: "🩹",
      definition: "Deep cut or tear in the skin that may require stitches.",
      example: "Clean lacerations need to be evaluated by a healthcare provider.",
    },
    {
      term: "Abrasion",
      commonName: "Scrape",
      icon: "🤕",
      definition: "Superficial scrape where skin is rubbed or scraped off.",
      example: "Clean abrasions with soap and water to prevent infection.",
    },
    {
      term: "Pyrexia",
      commonName: "Fever",
      icon: "🌡️",
      definition: "Elevated body temperature, usually above 100.4°F (38°C).",
      example: "Pyrexia is often a sign that the body is fighting an infection.",
    },
    {
      term: "Conjunctivitis",
      commonName: "Pink Eye",
      icon: "👁️",
      definition: "Inflammation or infection of the outer membrane of the eyeball and inner eyelid.",
      example: "Viral conjunctivitis is highly contagious and spreads easily.",
    },
    {
      term: "Otitis Media",
      commonName: "Ear Infection",
      icon: "👂",
      definition: "Infection of the middle ear, common in children.",
      example: "Otitis media often follows a cold or respiratory infection.",
    },
    {
      term: "Sinusitis",
      commonName: "Sinus Infection",
      icon: "😤",
      definition: "Inflammation or infection of the sinuses causing facial pain and congestion.",
      example: "Chronic sinusitis lasts longer than 12 weeks.",
    },
    {
      term: "Gastroenteritis",
      commonName: "Stomach Flu",
      icon: "🤢",
      definition: "Inflammation of the stomach and intestines causing vomiting and diarrhea.",
      example: "Viral gastroenteritis usually resolves on its own within a few days.",
    },
    {
      term: "Cystitis",
      commonName: "Bladder Infection",
      icon: "🔴",
      definition: "Inflammation of the bladder, usually caused by bacterial infection.",
      example: "Cystitis causes burning during urination and frequent urges to urinate.",
    },
    {
      term: "Arthralgia",
      commonName: "Joint Pain",
      icon: "🦵",
      definition: "Pain in one or more joints without inflammation.",
      example: "Arthralgia can be caused by many conditions including overuse or arthritis.",
    },
    {
      term: "Myalgia",
      commonName: "Muscle Pain",
      icon: "💪",
      definition: "Pain or aching in muscles.",
      example: "Myalgia is common after intense exercise or during viral infections like flu.",
    },
    {
      term: "Nausea",
      commonName: "Feeling Sick",
      icon: "🤮",
      definition: "Feeling of sickness with an urge to vomit.",
      example: "Nausea can be caused by many things including motion sickness and pregnancy.",
    },
    {
      term: "Pruritus",
      commonName: "Itching",
      icon: "🔴",
      definition: "Unpleasant sensation that causes desire to scratch.",
      example: "Pruritus can be caused by dry skin, allergies, or various skin conditions.",
    },
    {
      term: "Epistaxis",
      commonName: "Nosebleed",
      icon: "🩸",
      definition: "Bleeding from the nose.",
      example: "Most cases of epistaxis can be stopped by pinching the nose and leaning forward.",
    },
    {
      term: "Dysphagia",
      commonName: "Difficulty Swallowing",
      icon: "😣",
      definition: "Difficulty or discomfort when swallowing food or liquids.",
      example: "Persistent dysphagia should be evaluated by a doctor.",
    },
    {
      term: "Tinnitus",
      commonName: "Ringing in Ears",
      icon: "🔔",
      definition: "Perception of sound when no external sound is present, often ringing or buzzing.",
      example: "Tinnitus can be temporary or chronic and has many possible causes.",
    },
    {
      term: "Insomnia",
      commonName: "Can't Sleep",
      icon: "🌙",
      definition: "Difficulty falling asleep, staying asleep, or getting quality sleep.",
      example: "Good sleep hygiene can help improve insomnia.",
    },
    {
      term: "Malaise",
      commonName: "General Discomfort",
      icon: "😔",
      definition: "General feeling of being unwell, discomfort, or uneasiness.",
      example: "Malaise often accompanies the early stages of illness.",
    },
    {
      term: "Syncope",
      commonName: "Fainting",
      icon: "😵‍💫",
      definition: "Temporary loss of consciousness due to lack of blood flow to the brain.",
      example: "Syncope can be caused by dehydration, low blood sugar, or heart conditions.",
    },
    {
      term: "Angina",
      commonName: "Chest Pain",
      icon: "💔",
      definition: "Chest pain or discomfort caused by reduced blood flow to the heart muscle.",
      example: "Angina is a warning sign of heart disease and requires medical evaluation.",
    },
    {
      term: "Asthma",
      commonName: "Breathing Difficulty",
      icon: "🫁",
      definition: "Condition causing airways to narrow and swell, making breathing difficult.",
      example: "Asthma symptoms can be triggered by allergies, exercise, or cold air.",
    },
    {
      term: "Migraine",
      commonName: "Severe Headache",
      icon: "🤯",
      definition: "Severe headache often with throbbing pain, usually on one side of head.",
      example: "Migraines may be accompanied by nausea, vomiting, and sensitivity to light.",
    },
    {
      term: "Eczema",
      commonName: "Itchy Skin Patches",
      icon: "🔴",
      definition: "Condition causing patches of skin to become inflamed, itchy, cracked, and rough.",
      example: "Eczema often appears in childhood but can occur at any age.",
    },
  ]

  const filteredTerms = terms.filter(
    (term) =>
      term.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
      term.commonName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      term.definition.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Medical Dictionary</h1>
          <p className="text-sm text-white/90">Understand medical terms simply</p>
        </div>
      </div>

      {/* Search */}
      <div className="max-w-md mx-auto p-4">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder="Search terms like 'anemia', 'inflammation'..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 border-[#efddc7] dark:border-gray-700 focus:border-[#a27a69] dark:bg-gray-800 dark:text-gray-100"
          />
        </div>

        {/* Terms List */}
        <div className="space-y-4">
          {filteredTerms.map((item, index) => (
            <Card
              key={index}
              className="border-2 border-[#efddc7] dark:border-gray-700 hover:border-[#a27a69] transition-colors dark:bg-gray-800"
            >
              <CardContent className="p-4">
                <div className="flex items-start mb-3">
                  <span className="text-2xl mr-3">{item.icon}</span>
                  <div className="flex-1">
                    <h3 className="text-lg font-heading font-normal text-[#a27a69]">{item.term}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 italic">Also known as: {item.commonName}</p>
                  </div>
                </div>

                <div className="mb-3">
                  <h4 className="font-heading font-normal text-gray-800 dark:text-gray-200 mb-1">Definition:</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm">{item.definition}</p>
                </div>

                <div className="bg-[#efddc7] dark:bg-gray-700 p-3 rounded-lg">
                  <h4 className="font-heading font-normal text-[#a27a69] mb-1 text-sm">Example Use:</h4>
                  <p className="text-gray-700 dark:text-gray-300 text-sm italic">"{item.example}"</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTerms.length === 0 && searchTerm && (
          <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
            <CardContent className="p-8 text-center">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <h3 className="font-heading font-normal text-gray-600 dark:text-gray-400 mb-2">No terms found</h3>
              <p className="text-sm text-gray-500 dark:text-gray-500">Try searching for a different medical term</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
