"use client"

import { useState } from "react"
import { ArrowLeft, Save, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function HeadacheRemedies() {
  const [savedRemedies, setSavedRemedies] = useState<number[]>([])

  const remedies = [
    {
      title: "Cold Compress",
      symptoms: "Tension headaches, migraines",
      ingredients: ["Ice pack or cold cloth", "Towel"],
      steps: [
        "Wrap ice pack in a thin towel",
        "Apply to forehead or back of neck for 15 minutes",
        "Take 15-minute breaks between applications",
      ],
      cautions: "Don't apply ice directly to skin. Limit to 15 minutes at a time.",
    },
    {
      title: "Peppermint Oil",
      symptoms: "Tension headaches",
      ingredients: ["Peppermint essential oil", "Carrier oil (coconut/olive)"],
      steps: [
        "Mix 2-3 drops peppermint oil with 1 tsp carrier oil",
        "Gently massage temples and forehead",
        "Avoid getting oil near eyes",
      ],
      cautions: "Always dilute essential oils. Test on small skin area first.",
    },
    {
      title: "Hydration",
      symptoms: "Dehydration headaches",
      ingredients: ["Water", "Electrolyte solution (optional)"],
      steps: [
        "Drink 16-20 oz of water slowly",
        "Continue sipping water throughout the day",
        "Add electrolytes if sweating heavily",
      ],
      cautions: "Don't drink too much water too quickly.",
    },
  ]

  const toggleSave = (index: number) => {
    setSavedRemedies((prev) => (prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]))
  }

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/remedies">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Headache Remedies</h1>
          <p className="text-sm text-white/90">Natural relief for head pain</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        <div className="space-y-6">
          {remedies.map((remedy, index) => (
            <Card key={index} className="border-2 border-[#efddc7]">
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-lg font-heading font-normal text-[#a27a69]">{remedy.title}</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleSave(index)}
                    className={savedRemedies.includes(index) ? "text-[#a27a69]" : "text-gray-400"}
                  >
                    <Save className="w-4 h-4" />
                  </Button>
                </div>

                <div className="mb-3">
                  <h4 className="font-heading font-normal text-gray-800 mb-1">Treats:</h4>
                  <p className="text-sm text-gray-600">{remedy.symptoms}</p>
                </div>

                <div className="mb-3">
                  <h4 className="font-heading font-normal text-gray-800 mb-2">Ingredients:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {remedy.ingredients.map((ingredient, idx) => (
                      <li key={idx}>• {ingredient}</li>
                    ))}
                  </ul>
                </div>

                <div className="mb-4">
                  <h4 className="font-heading font-normal text-gray-800 mb-2">Steps:</h4>
                  <ol className="text-sm text-gray-600 space-y-1">
                    {remedy.steps.map((step, idx) => (
                      <li key={idx}>
                        {idx + 1}. {step}
                      </li>
                    ))}
                  </ol>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex items-start">
                  <AlertTriangle className="w-4 h-4 text-yellow-600 mr-2 mt-0.5 flex-shrink-0" />
                  <div>
                    <h5 className="font-heading font-normal text-yellow-800 text-sm mb-1">Cautions:</h5>
                    <p className="text-xs text-yellow-700">{remedy.cautions}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* When to See a Doctor */}
        <Card className="mt-6 bg-red-50 border-red-200">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-red-800 mb-2">🚨 See a Doctor If:</h3>
            <ul className="text-sm text-red-700 space-y-1">
              <li>• Sudden, severe headache unlike any before</li>
              <li>• Headache with fever, stiff neck, or rash</li>
              <li>• Headaches getting worse or more frequent</li>
              <li>• Headache after head injury</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
