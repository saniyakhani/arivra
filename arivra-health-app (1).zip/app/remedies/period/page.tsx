import { ArrowLeft } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function PeriodRemedies() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/remedies">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Period Pain Remedies</h1>
          <p className="text-sm text-white/90">Coming soon</p>
        </div>
      </div>
      <div className="max-w-md mx-auto p-4">
        <Card className="border-2 border-[#efddc7] dark:border-gray-700 dark:bg-gray-800">
          <CardContent className="p-8 text-center">
            <p className="text-gray-600 dark:text-gray-400">Content coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
