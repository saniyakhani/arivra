import { ArrowLeft, Brain, Droplets, Zap, Heart } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function HomeRemedies() {
  const categories = [
    {
      title: "Headaches",
      icon: Brain,
      count: "8 remedies",
      href: "/remedies/headaches",
      color: "text-purple-500",
    },
    {
      title: "Colds",
      icon: Droplets,
      count: "12 remedies",
      href: "/remedies/colds",
      color: "text-blue-500",
    },
    {
      title: "Stomach Aches",
      icon: Zap,
      count: "10 remedies",
      href: "/remedies/stomach",
      color: "text-green-500",
    },
    {
      title: "Period Pain",
      icon: Heart,
      count: "6 remedies",
      href: "/remedies/period",
      color: "text-red-500",
    },
  ]

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Home Remedies</h1>
          <p className="text-sm text-white/90">Natural relief options</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <h3 className="font-heading font-normal text-green-800 mb-2">🌿 Natural Healing</h3>
          <p className="text-sm text-green-700">
            These remedies use natural ingredients and methods. Always consult a healthcare provider for persistent
            symptoms.
          </p>
        </div>

        <div className="space-y-4">
          {categories.map((category, index) => (
            <Link key={index} href={category.href}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-[#efddc7] hover:border-[#a27a69]">
                <CardContent className="p-4 flex items-center">
                  <category.icon className={`w-12 h-12 ${category.color} mr-4`} />
                  <div className="flex-1">
                    <h3 className="font-heading font-normal text-gray-800 mb-1">{category.title}</h3>
                    <p className="text-sm text-gray-600">{category.count}</p>
                  </div>
                  <div className="text-[#a27a69]">→</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Featured Remedy */}
        <Card className="mt-8 bg-[#efddc7] border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">🍯 Featured Remedy</h3>
            <div className="mb-2">
              <h4 className="font-heading font-normal text-gray-800">Honey & Ginger Tea</h4>
              <p className="text-sm text-gray-600 mb-2">For sore throat and cough</p>
            </div>
            <p className="text-sm text-gray-700">
              Mix 1 tbsp honey + 1 tsp fresh ginger in warm water. Soothes throat and has antibacterial properties.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
