"use client"

import type React from "react"

import { useState } from "react"
import { Search, Brain, Heart, ClipboardList, BookOpen, Leaf, User, ChevronDown, ChevronUp } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const [isTipExpanded, setIsTipExpanded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const mainTiles = [
    {
      title: "Symptom Checker",
      icon: Brain,
      href: "/symptom-checker",
      description: "Get guidance on symptoms",
    },
    {
      title: "Life-Saving Skills",
      icon: Heart,
      href: "/life-saving",
      description: "Emergency procedures",
    },
    {
      title: "Vitals Check Guide",
      icon: ClipboardList,
      href: "/vitals",
      description: "Monitor your health",
    },
    {
      title: "Medical Dictionary",
      icon: BookOpen,
      href: "/dictionary",
      description: "Understand medical terms",
    },
    {
      title: "Home Remedies",
      icon: Leaf,
      href: "/remedies",
      description: "Natural relief options",
    },
    {
      title: "Profile/Settings",
      icon: User,
      href: "/profile",
      description: "Manage your preferences",
    },
  ]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/dictionary?search=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-6 rounded-b-3xl">
        <div className="max-w-md mx-auto">
          <h1 className="text-2xl font-heading font-normal mb-2 text-center">Welcome to Arivra Health</h1>
          <p className="text-center text-white/90 mb-6">Making medical knowledge accessible to everyone</p>

          {/* Search Bar */}
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Type a symptom or term..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white border-0 rounded-full h-12 text-gray-700"
              />
            </div>
          </form>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto p-6">
        {/* Main Tiles Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {mainTiles.map((tile, index) => (
            <Link key={index} href={tile.href}>
              <Card className="h-32 hover:shadow-lg transition-shadow cursor-pointer border-2 border-[#efddc7] hover:border-[#a27a69]">
                <CardContent className="p-4 flex flex-col items-center justify-center text-center h-full">
                  <tile.icon className="w-8 h-8 text-[#a27a69] mb-2" />
                  <h3 className="font-heading font-normal text-sm text-gray-800 mb-1">{tile.title}</h3>
                  <p className="text-xs text-gray-600">{tile.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Expandable Daily Health Tip */}
        <Card className="bg-[#efddc7] border-2 border-[#a27a69] overflow-hidden">
          <Button
            variant="ghost"
            className="w-full p-4 h-auto flex items-center justify-between hover:bg-[#a27a69]/10"
            onClick={() => setIsTipExpanded(!isTipExpanded)}
          >
            <div className="flex items-center gap-2">
              <span className="text-xl">💡</span>
              <h3 className="font-heading font-normal text-[#a27a69]">Daily Health Tip</h3>
            </div>
            {isTipExpanded ? (
              <ChevronUp className="w-5 h-5 text-[#a27a69]" />
            ) : (
              <ChevronDown className="w-5 h-5 text-[#a27a69]" />
            )}
          </Button>

          {isTipExpanded && (
            <CardContent className="pt-0 pb-4 px-4">
              <p className="text-sm text-gray-700 leading-relaxed">
                Stay hydrated! Aim for 8 glasses of water daily to support your body's natural functions. Proper
                hydration helps maintain energy levels, supports digestion, and keeps your skin healthy.
              </p>
            </CardContent>
          )}
        </Card>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#efddc7] px-4 py-2">
        <div className="max-w-md mx-auto flex justify-around">
          <Link href="/" className="flex flex-col items-center py-2 text-[#a27a69]">
            <div className="w-6 h-6 mb-1 flex items-center justify-center text-lg">🏠</div>
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/symptom-checker" className="flex flex-col items-center py-2 text-gray-500">
            <div className="w-6 h-6 mb-1 flex items-center justify-center text-lg">🤖</div>
            <span className="text-xs">Checker</span>
          </Link>
          <Link href="/life-saving" className="flex flex-col items-center py-2 text-gray-500">
            <div className="w-6 h-6 mb-1 flex items-center justify-center text-lg">🧠</div>
            <span className="text-xs">Learn</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-gray-500">
            <div className="w-6 h-6 mb-1 flex items-center justify-center text-lg">💾</div>
            <span className="text-xs">Saved</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center py-2 text-gray-500">
            <div className="w-6 h-6 mb-1 flex items-center justify-center text-lg">⋯</div>
            <span className="text-xs">More</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
