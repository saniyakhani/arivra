"use client"

import { useState } from "react"
import { ArrowLeft, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function AEDGuide() {
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "Turn On AED",
      content: "Open the AED case and turn it on. The device will give you voice prompts. Follow them carefully.",
      illustration: "🔌",
    },
    {
      title: "Expose Chest",
      content: "Remove all clothing from chest. Wipe chest dry if wet. Remove any medication patches.",
      illustration: "👕",
    },
    {
      title: "Attach Pads",
      content:
        "Peel and stick pads exactly as shown in pictures. One pad on upper right chest, one on lower left side.",
      illustration: "📋",
    },
    {
      title: "Clear and Analyze",
      content: "Make sure no one is touching the patient. AED will analyze heart rhythm. Stay clear during analysis.",
      illustration: "🔍",
    },
    {
      title: "Deliver Shock if Advised",
      content:
        "If shock advised, make sure everyone is clear. Press the shock button when AED tells you. Shout 'Clear!'",
      illustration: "⚡",
    },
    {
      title: "Resume CPR",
      content:
        "Immediately resume CPR after shock. Continue CPR until help arrives or person starts breathing normally.",
      illustration: "💪",
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/life-saving">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Using an AED</h1>
          <p className="text-sm text-white/90">
            Step {currentStep + 1} of {steps.length}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        {/* Warning Box */}
        <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800 mb-6">
          <CardContent className="p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-heading font-normal text-blue-800 dark:text-blue-200 mb-1">AEDs Save Lives!</h3>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                Using an AED along with CPR greatly increases survival chances during cardiac arrest.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Step Card */}
        <Card className="mb-6 border-2 border-[#a27a69] dark:bg-gray-800">
          <CardContent className="p-6 text-center">
            <div className="text-6xl mb-4">{steps[currentStep].illustration}</div>
            <h2 className="text-xl font-heading font-normal text-[#a27a69] mb-3">{steps[currentStep].title}</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{steps[currentStep].content}</p>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="border-[#a27a69] text-[#a27a69]"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>

          <div className="flex space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${index === currentStep ? "bg-[#a27a69]" : "bg-[#efddc7] dark:bg-gray-600"}`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
            disabled={currentStep === steps.length - 1}
            className="border-[#a27a69] text-[#a27a69]"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Key Points */}
        <Card className="bg-[#efddc7] dark:bg-gray-800 border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">💡 Key Points to Remember</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
              <li>• AEDs are safe and designed for non-medical users</li>
              <li>• Always make sure no one is touching patient before shock</li>
              <li>• Follow voice prompts exactly</li>
              <li>• Continue CPR between shocks</li>
              <li>• Leave AED pads attached until help arrives</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
