import { ArrowLeft, Heart, Droplets, Shield, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function LifeSaving() {
  const skills = [
    {
      title: "CPR",
      icon: Heart,
      description: "Cardiopulmonary resuscitation",
      href: "/life-saving/cpr",
      color: "text-red-500",
    },
    {
      title: "Stop a Bleed",
      icon: Droplets,
      description: "Control severe bleeding",
      href: "/life-saving/bleeding",
      color: "text-red-600",
    },
    {
      title: "Using a Tourniquet",
      icon: Shield,
      description: "Emergency bleeding control",
      href: "/life-saving/tourniquet",
      color: "text-orange-500",
    },
    {
      title: "Using an AED",
      icon: Zap,
      description: "Automated external defibrillator",
      href: "/life-saving/aed",
      color: "text-yellow-500",
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Life-Saving Skills</h1>
          <p className="text-sm text-white/90">Emergency procedures that save lives</p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-6">
          <h3 className="font-heading font-normal text-red-800 dark:text-red-200 mb-2">⚠️ Important Disclaimer</h3>
          <p className="text-sm text-red-700 dark:text-red-300">
            These guides are for educational purposes. Always call emergency services (911) first in life-threatening
            situations.
          </p>
        </div>

        <div className="space-y-4">
          {skills.map((skill, index) => (
            <Link key={index} href={skill.href}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-[#efddc7] dark:border-gray-700 hover:border-[#a27a69] dark:bg-gray-800">
                <CardContent className="p-4 flex items-center">
                  <skill.icon className={`w-12 h-12 ${skill.color} mr-4`} />
                  <div className="flex-1">
                    <h3 className="font-heading font-normal text-gray-800 dark:text-gray-200 mb-1">{skill.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{skill.description}</p>
                  </div>
                  <div className="text-[#a27a69]">→</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick Access Emergency Numbers */}
        <Card className="mt-8 bg-[#efddc7] dark:bg-gray-800 border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">📞 Emergency Numbers</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="dark:text-gray-300">Emergency Services:</span>
                <span className="font-heading dark:text-gray-200">911</span>
              </div>
              <div className="flex justify-between">
                <span className="dark:text-gray-300">Poison Control:</span>
                <span className="font-heading dark:text-gray-200">1-800-222-1222</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
