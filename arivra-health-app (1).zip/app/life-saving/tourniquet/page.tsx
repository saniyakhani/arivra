"use client"

import { useState } from "react"
import { ArrowLeft, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function TourniquetGuide() {
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "When to Use",
      content:
        "Use a tourniquet ONLY when direct pressure fails to stop severe arm or leg bleeding that threatens life.",
      illustration: "⚠️",
    },
    {
      title: "Position Tourniquet",
      content: "Place tourniquet 2-3 inches above the wound, between the wound and the heart. Never place on a joint.",
      illustration: "📍",
    },
    {
      title: "Wrap and Secure",
      content:
        "Wrap the tourniquet around the limb twice and tie a half-knot. Use commercial tourniquet or wide cloth (2+ inches).",
      illustration: "🔄",
    },
    {
      title: "Tighten Until Bleeding Stops",
      content: "Place a stick over the knot, tie another knot. Twist the stick until bleeding completely stops.",
      illustration: "🔧",
    },
    {
      title: "Secure the Stick",
      content: "Secure the stick so it doesn't unwind. Note the time you applied the tourniquet.",
      illustration: "⏰",
    },
    {
      title: "Monitor and Wait",
      content:
        "Do NOT loosen or remove. Mark 'TK' and time on patient's forehead. Wait for emergency medical services.",
      illustration: "👨‍⚕️",
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/life-saving">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Using a Tourniquet</h1>
          <p className="text-sm text-white/90">
            Step {currentStep + 1} of {steps.length}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        {/* Warning Box */}
        <Card className="bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800 mb-6">
          <CardContent className="p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-heading font-normal text-red-800 dark:text-red-200 mb-1">Last Resort Only!</h3>
              <p className="text-sm text-red-700 dark:text-red-300">
                Use tourniquets only when direct pressure fails. Improper use can cause limb damage.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Step Card */}
        <Card className="mb-6 border-2 border-[#a27a69] dark:bg-gray-800">
          <CardContent className="p-6 text-center">
            <div className="text-6xl mb-4">{steps[currentStep].illustration}</div>
            <h2 className="text-xl font-heading font-normal text-[#a27a69] mb-3">{steps[currentStep].title}</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{steps[currentStep].content}</p>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="border-[#a27a69] text-[#a27a69]"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>

          <div className="flex space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${index === currentStep ? "bg-[#a27a69]" : "bg-[#efddc7] dark:bg-gray-600"}`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
            disabled={currentStep === steps.length - 1}
            className="border-[#a27a69] text-[#a27a69]"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Key Points */}
        <Card className="bg-[#efddc7] dark:bg-gray-800 border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">💡 Key Points to Remember</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
              <li>• NEVER loosen or remove once applied</li>
              <li>• Use wide material (2+ inches), never wire or rope</li>
              <li>• Place 2-3 inches above wound, never on joint</li>
              <li>• Record exact time of application</li>
              <li>• Seek emergency medical care immediately</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
