"use client"

import { useState } from "react"
import { ArrowLeft, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function StopBleedGuide() {
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "Ensure Safety",
      content: "Make sure the scene is safe. Wear gloves if available to protect yourself from bloodborne pathogens.",
      illustration: "🧤",
    },
    {
      title: "Call for Help",
      content: "Call 911 immediately for severe bleeding. Have someone call while you provide aid.",
      illustration: "📞",
    },
    {
      title: "Apply Direct Pressure",
      content: "Place clean cloth or gauze directly on the wound. Press firmly with your palm and hold continuously.",
      illustration: "✋",
    },
    {
      title: "Maintain Pressure",
      content: "Keep pressing for at least 3 minutes without peeking. If blood soaks through, add more cloth on top.",
      illustration: "⏱️",
    },
    {
      title: "Elevate if Possible",
      content: "If no broken bones, raise the injured area above the heart level while maintaining pressure.",
      illustration: "⬆️",
    },
    {
      title: "Apply Bandage",
      content: "Once bleeding slows, secure with firm bandage. Keep elevated and watch for shock until help arrives.",
      illustration: "🩹",
    },
  ]

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/life-saving">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">Stop a Bleed</h1>
          <p className="text-sm text-white/90">
            Step {currentStep + 1} of {steps.length}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        {/* Warning Box */}
        <Card className="bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800 mb-6">
          <CardContent className="p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-heading font-normal text-red-800 dark:text-red-200 mb-1">
                Life-Threatening Bleeding!
              </h3>
              <p className="text-sm text-red-700 dark:text-red-300">
                Severe bleeding can be fatal in minutes. Act quickly and call 911.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Step Card */}
        <Card className="mb-6 border-2 border-[#a27a69] dark:bg-gray-800">
          <CardContent className="p-6 text-center">
            <div className="text-6xl mb-4">{steps[currentStep].illustration}</div>
            <h2 className="text-xl font-heading font-normal text-[#a27a69] mb-3">{steps[currentStep].title}</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{steps[currentStep].content}</p>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="border-[#a27a69] text-[#a27a69]"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>

          <div className="flex space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${index === currentStep ? "bg-[#a27a69]" : "bg-[#efddc7] dark:bg-gray-600"}`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
            disabled={currentStep === steps.length - 1}
            className="border-[#a27a69] text-[#a27a69]"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Key Points */}
        <Card className="bg-[#efddc7] dark:bg-gray-800 border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">💡 Key Points to Remember</h3>
            <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
              <li>• Don't remove cloth if blood soaks through - add more on top</li>
              <li>• Maintain firm, continuous pressure</li>
              <li>• Use tourniquet only if direct pressure fails</li>
              <li>• Watch for signs of shock (pale, cold, rapid pulse)</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
