"use client"

import { useState } from "react"
import { ArrowLeft, ChevronLeft, ChevronRight, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function CPRGuide() {
  const [currentStep, setCurrentStep] = useState(0)

  const steps = [
    {
      title: "Check Responsiveness",
      content: "Tap the person's shoulders firmly and shout 'Are you okay?' Look for normal breathing.",
      illustration: "👤",
    },
    {
      title: "Call for Help",
      content: "Call 911 immediately. Ask someone to find an AED if available.",
      illustration: "📞",
    },
    {
      title: "Position Hands",
      content:
        "Place heel of one hand on center of chest between nipples. Place other hand on top, interlacing fingers.",
      illustration: "🙌",
    },
    {
      title: "Start Compressions",
      content: "Push hard and fast at least 2 inches deep. Allow complete chest recoil. Rate: 100-120 per minute.",
      illustration: "💪",
    },
    {
      title: "Give Rescue Breaths",
      content: "After 30 compressions, tilt head back, lift chin. Give 2 breaths, each lasting 1 second.",
      illustration: "💨",
    },
    {
      title: "Continue Cycles",
      content: "Continue 30 compressions followed by 2 breaths until help arrives or person starts breathing.",
      illustration: "🔄",
    },
  ]

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <div className="bg-[#a27a69] text-white p-4 flex items-center">
        <Link href="/life-saving">
          <ArrowLeft className="w-6 h-6 mr-3" />
        </Link>
        <div>
          <h1 className="text-xl font-heading font-normal">CPR Instructions</h1>
          <p className="text-sm text-white/90">
            Step {currentStep + 1} of {steps.length}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto p-4">
        {/* Warning Box */}
        <Card className="bg-red-50 border-red-200 mb-6">
          <CardContent className="p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-heading font-normal text-red-800 mb-1">Call 911 First!</h3>
              <p className="text-sm text-red-700">Always call emergency services before starting CPR.</p>
            </div>
          </CardContent>
        </Card>

        {/* Step Card */}
        <Card className="mb-6 border-2 border-[#a27a69]">
          <CardContent className="p-6 text-center">
            <div className="text-6xl mb-4">{steps[currentStep].illustration}</div>
            <h2 className="text-xl font-heading font-normal text-[#a27a69] mb-3">{steps[currentStep].title}</h2>
            <p className="text-gray-700 leading-relaxed">{steps[currentStep].content}</p>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="border-[#a27a69] text-[#a27a69]"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Previous
          </Button>

          <div className="flex space-x-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full ${index === currentStep ? "bg-[#a27a69]" : "bg-[#efddc7]"}`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
            disabled={currentStep === steps.length - 1}
            className="border-[#a27a69] text-[#a27a69]"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Key Points */}
        <Card className="bg-[#efddc7] border-0">
          <CardContent className="p-4">
            <h3 className="font-heading font-normal text-[#a27a69] mb-3">💡 Key Points to Remember</h3>
            <ul className="text-sm text-gray-700 space-y-1">
              <li>• Push hard, push fast (2+ inches deep)</li>
              <li>• Allow complete chest recoil</li>
              <li>• Minimize interruptions</li>
              <li>• Switch with someone every 2 minutes if possible</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
